/*
* Copyright (c) 2018, Texas Instruments Incorporated
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
*
* * Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
*
* * Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in the
* documentation and/or other materials provided with the distribution.
*
* * Neither the name of Texas Instruments Incorporated nor the names of
* its contributors may be used to endorse or promote products derived
* from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
* THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
* PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
* EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
* OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*
 * gc global variable provides access to GUI Composer infrastructure components and project information.
 * For more information, please see the Working with Javascript guide in the online help.
 */
var gc = gc || {};
gc.services = gc.services || {};

/*
*  Boilerplate code for creating computed data bindings
*/
document.addEventListener('gc-databind-ready', function() 
{
    /* 
	*   Add custom computed value databindings here, using the following method:
	*
    *   function gc.databind.registry.bind(targetBinding, modelBinding, [getter], [setter]);
	*
	*   param targetBinding - single binding string or expression, or array of binding strings for multi-way binding.
	*   param modelBinding - single binding string or expression, or array of binding strings for multi-way binding.
	*   param getter - (optional) - custom getter function for computing the targetBinding value(s) based on modelBinding value(s).
	*   param setter - (optional) - custom setter function for computing the modelBinding value(s) based on targetBinding value(s).
    */
	
	// For example, a simple computed values based on simple expression
	// gc.databind.registry.bind('widget.id.propertyName', "targetVariable == 1 ? 'binding is one' : 'binding is not one'");
	
	// Or a custom two-way binding with custome getter and setter functions.  (setter is optional)  (getter only indicates one-way binding)
	// gc.databind.registry.bind('widget.id.propertyName', "targetVariable", function(value) { return value*5/9 + 32; }, function(value) { (return value-32)*9/5; });
	
	// Event 1 to n bindings
	/* 
    gc.databind.registry.bind('widget.date.value', 
        // dependant bindings needed in order to compute the date, in name/value pairs.
        {
            weekday: 'widget.dayOfWeek.selectedText',
            day: 'widget.dayOfMonth.value',
            month: 'widget.month.selectedText',
            year: 'widget.year.value'
        }, 
        // getter for date computation
        function(values) 
        {
            // compute and return the string value to bind to the widget with id 'date'
            return values.weekday + ', ' + values.month + ' ' + values.day + ', ' + values.year;
        }
    ); 
	*/
});

/*
*  Boilerplate code for creating custom actions
*/
document.addEventListener('gc-nav-ready', function() 
{
    /* 
	*   Add custom actions for menu items using the following api:
	*
    *   function gc.nav.registryAction(id, runable, [isAvailable], [isVisible]);
	*
	*   param id - uniquely identifies the action, and should correspond to the action property of the menuaction widget.
	*   param runable - function that performs the custom action.
	*   param isAvailable - (optional) - function called when the menu action is about to appear.  Return false to disable the action, or true to enable it.
	*   param isVisible - (optional) - function called when the menu action is about to appear.  Return false to hide the action, or true to make it visible.
    */
	
	// For example,
	// gc.nav.registerAction('myCustomCloseAction', function() { window.close(); }, function() { return true; }, function() { return true; });
	
	// Alternatively, to programmatically disable a menu action at any time use:
	// gc.nav.disableAction('myCustomCloseAction);    then enable it again using:  gc.nav.enableAction('myCustomCloseAction'); 
});

/*
*  Boilerplate code for working with components in the application gist
*/

var initComplete = false;
var templateObj;

var dacDataArray = [];
var dacPlotObj;
var dacPlotOptions;
var adcPlotObj;
var adcFreq = 512;
var updateDAC;

// Array for volts
var voltDataArray = [];
var voltPlotOptions;
var voltPlotObj;

// Array for volts
var dlaDataArray = [];
var dlaPlotOptions;
var dlaPlotObj;

// Wait for DOMContentLoaded event before trying to access the application template
var init = function() {
    templateObj = document.querySelector('#template_obj');

    // Wait for the template to fire a dom-change event to indicate that it has been 'stamped'
    // before trying to access components in the application.
	templateObj.addEventListener('dom-change',function(){
	    if (initComplete) return;
	    this.async(function(){
    	    initComplete = true;
    	    console.log("Application template has been stamped.");
  	        // Now that the template has been stamped, you can use 'automatic node finding' $ syntax to access widgets.
  	        // e.g. to access a widget with an id of 'widget_id' you can use templateObj.$.widgetId
  	        
  	          	        // Override default Software Manifest
            var aboutBox = document.querySelector('ti-widget-aboutbox');    
            aboutBox.addEventListener("aboutbox_opening", function(event){
                aboutBox.softwareManifestLink = "app/docs/MSP-EXP430FR2355LaunchPadOOBDemoGUI_manifest.html";
            });
  	        
            var navigatejs = document.createElement("script");
            
            navigatejs.type = "text/javascript";
            navigatejs.src = "app/js/jquery.flot.navigate.js";
            
            navigatejs.onload = function() {
                
                $("#ti_widget_scalargraph_dac").find("#xAxisLabel").html("Samples per second");
                $("#ti_widget_scalargraph_adc").find("#xAxisLabel").html("Samples per second");
                $("#ti_widget_scalargraph_vlt").find("#xAxisLabel").html("Volts per second");
                
      	        updateDAC = function () {
      	            dacDataArray = [];
      	            voltDataArray = [];

      	            var signalType = templateObj.$.ti_widget_droplist_signal_type.selectedIndex;
      	            var signalFreq = Math.round(Math.pow(2, templateObj.$.ti_widget_slider_signal_freq.value));
      	            var signalAmp = templateObj.$.ti_widget_slider_signal_amp.value;
      	            var dacFreq = Math.round(Math.pow(2, templateObj.$.ti_widget_slider_dac_freq.value));
      	            var sampleLen = dacFreq / signalFreq;
      	            var opAmpMode = templateObj.$.ti_widget_droplist_opamp_mode.selectedIndex;
      	            var dcBias = (opAmpMode === 0) ? 1.65 : signalAmp;
      	            
                    switch (signalType) {
                        // Sine function
                        case 0:
                            x = 2 * Math.PI * signalFreq / dacFreq;
                            for (i = 0; i < sampleLen; i++) {
                                dacDataArray.push([i, signalAmp * Math.sin(i * x) + dcBias]);
                                voltDataArray.push([i, 10]);
                            }
                            break;
                        // Square function
                        case 1:
                            for (i = 0; i < sampleLen/2; i++) {
                                dacDataArray.push([i, dcBias + signalAmp]);
                                voltDataArray.push([i, 10]);
                            }
                            for (i = sampleLen/2; i < sampleLen; i++) {
                                dacDataArray.push([i, dcBias - signalAmp]);
                                voltDataArray.push([i, 10]);
                            }
                            break;
                        // Sawtooth function
                        case 2:
                            x = signalAmp * 2 / sampleLen;
                            for (i = 0; i < sampleLen; i++) {
                                dacDataArray.push([i, i * x + dcBias - signalAmp]);
                                voltDataArray.push([i, 10]);
                            }
                            break;
                        default:
                            break;
                    }
                    // For Function Generator 
                    while(dacDataArray.length < dacFreq) {
                        for (j = 0; j < sampleLen; j++) {
                            dacDataArray.push([dacDataArray.length, dacDataArray[j][1]]);
                        }
                    }
                    dacDataArray.push([dacDataArray.length, dacDataArray[dacDataArray.length-1][1]]);
                    
                    // For Voltmeter
                    while(voltDataArray.length < dacFreq) {
                        for (j = 0; j < sampleLen; j++) {
                            voltDataArray.push([voltDataArray.length, voltDataArray[j][1]]);
                        }
                    }
                    voltDataArray.push([voltDataArray.length, voltDataArray[voltDataArray.length-1][1]]);
              
                ////////////////////////////////////////////////////////////////////////////////////////////
                ////////////////////////////////////////////////////////////////////////////////////////////
                    
                    dacPlotOptions = {
                        series: {
                            lines: {show: true, steps: true}
                            // points: {show: true}
                        },
                        xaxis: {
                            min: 0,
                            max: dacFreq,
                            zoomRange:[0.1, dacFreq],
                            panRange:[0, dacFreq]
                        },
                        yaxis: {
                            max: 3.3,
                            min: 0,
                            zoomRange:[0.1, 3.3],
                            panRange:[0, 3.3]
                        },
                        colors: ["#00bbcc"],
                        grid: {
                            hoverable: true,
                            autoHighlight: true
                        },
                        zoom: {
                            interactive: true
                        },
                        pan: {
                            interactive: true
                        }
                    }
                    dacPlotObj = $.plot(templateObj.$.ti_widget_scalargraph_dac.querySelector("#chart"), [ dacDataArray ], dacPlotOptions);
                    
                    var vltPlotOptions = {
                        series: {
                            lines: {show: true, steps: true}
                            // points: {show: true}
                        },
                        xaxis: {
                            min: 0,
                            max: 1,
                            zoomRange:[0.1, 1],
                            panRange:[0, 2]
                        },
                        yaxis: {
                            max: 33,
                            min: 0,
                            zoomRange:[0.1, 33],
                            panRange:[0, 33]
                        },
                        colors: ["#00bbcc"],
                        grid: {
                            hoverable: true,
                            autoHighlight: true
                        },
                        zoom: {
                            interactive: true
                        },
                        pan: {
                            interactive: true
                        }
                    }
                    voltPlotObj = $.plot(templateObj.$.ti_widget_scalargraph_vlt.querySelector("#chart"), [ voltDataArray ], vltPlotOptions);
                    var voltObj1 = $.plot(templateObj.$.ti_widget_scalargraph_ps.querySelector("#chart"), [ voltDataArray ], vltPlotOptions);

      	        };

                var plotOptions = {
                    series: {
                        lines: {show: true, steps: true}
                        // points: {show: true}
                    },
                    xaxis: {
                        min: 0,
                        max: 512,
                        zoomRange:[0.1, 512],
                        panRange:[0, 512]
                    },
                    yaxis: {
                        max: 3.3,
                        min: 0,
                        zoomRange:[0.1, 3.3],
                        panRange:[0, 3.3]
                    },
                    colors: ["#00bbcc"],
                    grid: {
                        hoverable: true,
                        autoHighlight: true
                    },
                    zoom: {
                        interactive: true
                    },
                    pan: {
                        interactive: true
                    }
                }
                adcPlotObj = $.plot(templateObj.$.ti_widget_scalargraph_adc.querySelector("#chart"), [[[0, 0]]], plotOptions);

                
            	$("<div id='datatag'></div>").css({
            		position: "absolute",
            		display: "none",
            		border: "1px solid #fdd",
            		padding: "2px",
            		"background-color": "#fee",
            		opacity: 0.80
            	}).appendTo("body");
        		
        		$("#ti_widget_scalargraph_adc").find("#chart").bind("plothover", function (event, pos, item) {
    				if (item) {
    					var x = item.datapoint[0],
    						y = item.datapoint[1].toFixed(2);
    
    					$("#datatag").html("(" + x + ", " + y + ")")
    						.css({top: item.pageY+5, left: item.pageX+5})
    						.fadeIn(200);
    				} else {
    					$("#datatag").hide();
    				}
        		});
        		
        		$("#ti_widget_scalargraph_dac").find("#chart").bind("plothover", function (event, pos, item) {
    				if (item) {
    					var x = item.datapoint[0],
    						y = item.datapoint[1].toFixed(2);
    
    					$("#datatag").html("(" + x + ", " + y + ")")
    						.css({top: item.pageY+5, left: item.pageX+5})
    						.fadeIn(200);
    				} else {
    					$("#datatag").hide();
    				}
        		});
        		
        		$("#ti_widget_scalargraph_vlt").find("#chart").bind("plothover", function (event, pos, item) {
    				if (item) {
    					var x = item.datapoint[0],
    						y = item.datapoint[1].toFixed(2);
    
    					$("#datatag").html("(" + x + ", " + y + ")")
    						.css({top: item.pageY+5, left: item.pageX+5})
    						.fadeIn(200);
    				} else {
    					$("#datatag").hide();
    				}
        		});
        		
        		updateDAC();
                
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                
                // This handles the Oscilloscope function off button
                templateObj.$.ti_widget_button_enable_lightsensor.onclick = function(){

                    //This disables the Oscilloscope
                    templateObj.$.my_usb_uart.sendValue({"mode":0});
                    
                    updateDAC();
                }
                
                templateObj.$.ti_widget_button_enable_sac.onclick = function(){
                    console.log("sending" + {"mode":1});
                    // This enables oscilloscope
                    templateObj.$.my_usb_uart.sendValue({"mode":1});
                }
                
        		// This handles the amp mode for the DAC and then updates it 
        		templateObj.$.ti_widget_droplist_opamp_mode.onchange = function() {
        		    updateDAC();
        		    
                    if (this.selectedIndex === 0) {
                        templateObj.$.ti_widget_slider_opamp_gain.labels = "1,2,4,8,16,25,32";
                        templateObj.$.ti_widget_slider_opamp_gain.minValue = 1;
                        templateObj.$.ti_widget_slider_opamp_gain.maxValue = 7;
                        
                        var changeCallback = templateObj.$.ti_widget_slider_opamp_gain.onchange;
                        templateObj.$.ti_widget_slider_opamp_gain.onchange = null;
                        templateObj.$.ti_widget_slider_opamp_gain.value = 1;
                        templateObj.$.ti_widget_slider_opamp_gain.onchange = changeCallback;
                        
                        if (templateObj.$.ti_widget_droplist_input_signal_source.selectedIndex === 0)
                            templateObj.$.ti_widget_image1.imagePath = "Image/Internal_DAC_Invert.png"
                    }
                    else if (this.selectedIndex == 1) {
                        templateObj.$.ti_widget_slider_opamp_gain.labels = "1,2,3,5,9,17,26,33";
                        templateObj.$.ti_widget_slider_opamp_gain.minValue = 0;
                        templateObj.$.ti_widget_slider_opamp_gain.maxValue = 7;
                        
                        var changeCallback = templateObj.$.ti_widget_slider_opamp_gain.onchange;
                        templateObj.$.ti_widget_slider_opamp_gain.onchange = null;
                        templateObj.$.ti_widget_slider_opamp_gain.value = 0;
                        templateObj.$.ti_widget_slider_opamp_gain.onchange = changeCallback;
                        
                    }
                    templateObj.$.my_usb_uart.sendValue({"opAmpMode":this.selectedIndex, "opAmpGain":templateObj.$.ti_widget_slider_opamp_gain.value});
                };
                
                templateObj.$.ti_widget_droplist_input_signal_source.onchange = function() {
                    updateDAC();
                    var inputSignalSource = templateObj.$.ti_widget_droplist_input_signal_source.selectedIndex;
                    templateObj.$.my_usb_uart.sendValue({"inputSignalSource":inputSignalSource});
                    switch (inputSignalSource) {
                        case 0:
                            templateObj.$.ti_widget_droplist_opamp_mode.disabled = false;
                            if (templateObj.$.ti_widget_droplist_opamp_mode.selectedIndex === 0)
                                templateObj.$.ti_widget_image1.imagePath = "Images/Internal_DAC_Invert.png"
                    }
                };
                
                templateObj.$.ti_widget_droplist_signal_type.onchange = function() {
                    updateDAC();
                    var signalType = templateObj.$.ti_widget_droplist_signal_type.selectedIndex;
                    templateObj.$.my_usb_uart.sendValue({"signalType":signalType});
                };
                
        // 		templateObj.$.ti_widget_slider_signal_freq.children[0].children[1]._immediateValueChanged = function() {
                templateObj.$.ti_widget_slider_signal_freq.onchange = function() {
                    updateDAC();
                    var signalFreq = Math.round(Math.pow(2, templateObj.$.ti_widget_slider_signal_freq.value));
                    templateObj.$.my_usb_uart.sendValue({"signalFreq":signalFreq});
                };
                
        // 		templateObj.$.ti_widget_slider_signal_amp.children[0].children[1]._immediateValueChanged = function() {
        		templateObj.$.ti_widget_slider_signal_amp.onchange = function() {
                    updateDAC();
                    var signalAmp = Math.round((templateObj.$.ti_widget_slider_signal_amp.value/3.3) * 4095);
                    templateObj.$.my_usb_uart.sendValue({"signalAmp":signalAmp});
                };
                
        // 		templateObj.$.ti_widget_slider_dac_freq.children[0].children[1]._immediateValueChanged = function() {
        		templateObj.$.ti_widget_slider_dac_freq.onchange = function() {
                    updateDAC();
                    var dacFreq = Math.round(Math.pow(2, templateObj.$.ti_widget_slider_dac_freq.value));
                    templateObj.$.my_usb_uart.sendValue({"dacFreq":dacFreq});
                };
                
        		templateObj.$.ti_widget_slider_adc_freq.onchange = function() {
        		    updateDAC();
                    adcFreq = Math.round(Math.pow(2, templateObj.$.ti_widget_slider_adc_freq.value));
                    templateObj.$.my_usb_uart.sendValue({"adcFreq":adcFreq});
                };
                
        // 		templateObj.$.ti_widget_slider_opamp_gain.children[0].children[1]._immediateValueChanged = function() {
        		templateObj.$.ti_widget_slider_opamp_gain.onchange = function() {
        		    upDateDAC();
        		    console.log({"opAmpGain":this.value});
        		    templateObj.$.my_usb_uart.sendValue({"opAmpGain":this.value});
                };
                
                function updateLaunchPad() {
      	            var signalType = templateObj.$.ti_widget_droplist_signal_type.selectedIndex;
      	            var signalFreq = Math.round(Math.pow(2, templateObj.$.ti_widget_slider_signal_freq.value));
      	            var signalAmp = Math.round((templateObj.$.ti_widget_slider_signal_amp.value/3.3) * 4095);
      	            var dacFreq = Math.round(Math.pow(2, templateObj.$.ti_widget_slider_dac_freq.value));
      	            
      	            adcFreq = Math.round(Math.pow(2, templateObj.$.ti_widget_slider_adc_freq.value));
      	            
      	            var opAmpMode = templateObj.$.ti_widget_droplist_opamp_mode.selectedIndex;
      	            var opAmpGain = templateObj.$.ti_widget_slider_opamp_gain.value;
      	            
      	         //   console.log({"signalType":signalType, "signalFreq":signalFreq, "signalAmp":signalAmp, "dacFreq":dacFreq, "adcFreq":adcFreq, "opAmpMode":opAmpMode, "opAmpGain":opAmpGain, "enableSignal":true});
                    templateObj.$.my_usb_uart.sendValue({
                        "signalType":signalType,
                        "signalFreq":signalFreq,
                        "signalAmp":signalAmp,
                        "dacFreq":dacFreq,
                        "adcFreq":adcFreq,
                        "opAmpMode":opAmpMode,
                        "opAmpGain":opAmpGain
                    });
                }
                
                window.addEventListener("resize", function() {
                    console.log("resize event");
                    setTimeout(updateDAC,300);
                    // updateDAC();
                    // dacPlotObj = $.plot(templateObj.$.ti_widget_scalargraph_dac.querySelector("#chart"), [ dacDataArray ], dacPlotOptions);
                });
            };
            
            document.body.appendChild(navigatejs);
        },500);

	});
};

templateObj = document.querySelector('#template_obj');
if (templateObj) {
    init();
} else {
    document.addEventListener('DOMContentLoaded',init.bind(this))
}


