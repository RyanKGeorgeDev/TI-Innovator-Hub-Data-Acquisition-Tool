/*
* Copyright (c) 2018, Texas Instruments Incorporated
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
*
* * Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
*
* * Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in the
* documentation and/or other materials provided with the distribution.
*
* * Neither the name of Texas Instruments Incorporated nor the names of
* its contributors may be used to endorse or promote products derived
* from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
* THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
* PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
* EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
* OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*
 * gc global variable provides access to GUI Composer infrastructure components and project information.
 * For more information, please see the Working with Javascript guide in the online help.
 */
var gc = gc || {};
gc.services = gc.services || {};


/*
 *  Boilerplate code for encoding and decoding data transmitted to / received from TI devices.
 */

/**
 * This code implements the IPacketCodec interface.
 *
 * @constructor
 * @implements gc.databind.IPacketCodec
 */
CustomCodec = function()
{
};
CustomCodec.prototype.rxPktCtr = 0;
CustomCodec.prototype.rxMsgCtr = 0;
CustomCodec.prototype.txPktCtr = 0;
CustomCodec.prototype.txMsgCtr = 0;
CustomCodec.prototype.strRxBuffer = "";
CustomCodec.prototype.strTxBuffer = "";
CustomCodec.prototype.isConnected = false;
CustomCodec.prototype.initComplete = false;
CustomCodec.prototype.templateObj = undefined;



/**
 * Encodes data into a packet for sending to the target device.
 *
 * @param target - function to call to pass on the encoded data towards the target
 * @param data - The object containing the binding properties from the GUI that is to be encoded into a packet for sending.
 */
CustomCodec.prototype.encode = function(target,data){
    this.txPktCtr++;

   // The following example code shows how to encode property values from the GUI into
   // a JSON formatted string.  You would use this if you wanted to intercept data from the GUI
   // and rework it before passing it on to the target device.

   try{
        this.txMsgCtr++;
        if (this.txMsgCtr % 256){
            console.log("Number of tx messages to target: "+this.txMsgCtr);
        }
        var strToSend = JSON.stringify(data) +"\n";
        // send the string to the target
        target(strToSend);
    }
    catch(ex){
        console.log("CustomCodec.encode (to target): exception="+ex);
    }
};


var rawADCArray = [];
var count = 0;
var index = 0;

/**
 * Decodes packets from the target device into data objects.  One object for each packet of data.
 * Unless you have chained your custom codec with the CR codec, the packet data is not framed,
 * so this method is responsible for decoding partial packets as well as multiple packets.  Partial packets
 * should not be returned, but deferred until the next decode method call with more raw data to process.  As a
 * result, this method may return 0 or more packets of data on each invocation.
 *
 * @param target -  function to call to pass on the encoded data towards the GUI
 * @param data  - The raw data received that needs to be decoded from packets into objects.
 * @return - true if connected (i.e. valid data received), false if not connected
 */
CustomCodec.prototype.decode = function(target, data) {
    this.isConnected = true;
    this.rxPktCtr++;

    // The following example code shows how to decode JSON strings coming up from the target
    // into a Javascript object.  You would use this if you wanted to intercept data from the target
    // and rework it before passing it on to the GUI for binding

    var strRxData = data.map(function(value) { return String.fromCharCode(value);} ).join("");
    this.strRxBuffer = this.strRxBuffer+strRxData;
    var strMessage = '';
    while (this.strRxBuffer.indexOf('\n') !== -1) {
        strMessage = this.strRxBuffer.substring(0, this.strRxBuffer.indexOf('\n') + 1);
        this.strRxBuffer = this.strRxBuffer.substring(strMessage.length);
        // Rework the following code if your codec is not receiving Javascript objects from the GUI
        try {
            var jsonObj = JSON.parse(strMessage);
            this.rxMsgCtr++;
            // if (this.rxMsgCtr % 256){
            //     console.log("Number of tx messages from target: "+this.rxMsgCtr);
            // }

            // send the received and decoded javascript object to the application where you can use it to bind to widget properties
            // target(jsonObj);
            
            // console.log(jsonObj.a);
            
            
            // if (rawADCArray.length >= adcFreq) {
            //     // rawADCArray.shift();
            //     var tempArray = [];
            //     for (i = 1; i < rawADCArray.length; i++) {
            //         tempArray.push([i, rawADCArray[i][1]]);
            //     }
            //     rawADCArray = tempArray;
            // }
            
            if (jsonObj.a !== undefined) {
                rawADCArray[index] = [index, (jsonObj.a/4095.0) * 3.3];
                if (++index >= adcFreq) {
                    rawADCArray[index] = [index, rawADCArray[index-1][1]];
                    index = 0;
                }
                
                if (++count >= (adcFreq/30)) {
                    count = 0;
                    // $.plot(templateObj.$.ti_widget_scalargraph_adc.querySelector("#chart"), [ rawADCArray ], plotOptions);
                    adcPlotObj.getOptions().grid.markings = [{ xaxis: { from: index, to: index }, color: "#FF0000" }];
                    adcPlotObj.getOptions().xaxes[0].max = adcFreq;
                    adcPlotObj.getOptions().xaxes[0].zoomRange = [0.1, adcFreq];
                    adcPlotObj.getOptions().xaxes[0].panRange = [0, adcFreq];
                    adcPlotObj = $.plot(templateObj.$.ti_widget_scalargraph_adc.querySelector("#chart"), [ rawADCArray ], adcPlotObj.getOptions());
                }
            }
            if (jsonObj.clear !== undefined) {
                rawADCArray = [];
                index = 0;
            }
    
            if (jsonObj.inputSignalSource !== undefined) {
                console.log("inputSignalSource set to " + jsonObj.inputSignalSource);
                templateObj.$.ti_widget_droplist_input_signal_source.selectedIndex = jsonObj.inputSignalSource;
                // templateObj.$.ti_widget_droplist_input_signal_source.onchange();
                
                switch (jsonObj.inputSignalSource) {
                    case 0:
                        if (templateObj.$.ti_widget_droplist_opamp_mode.selectedIndex === 0)
                            templateObj.$.ti_widget_image.imagePath = "Images/Internal_DAC_Inverting.png"
                        else
                            templateObj.$.ti_widget_image.imagePath = "image/Internal_DAC_Noninverting.png"
                        break;
                    case 1:
                        templateObj.$.ti_widget_image.imagePath = "image/P1_6_Inverting.png"
                        templateObj.$.ti_widget_droplist_opamp_mode.selectedIndex = 0;
                        break;
                    case 2:
                        templateObj.$.ti_widget_image.imagePath = "image/P1_7_Noninverting.png"
                        templateObj.$.ti_widget_droplist_opamp_mode.selectedIndex = 1;
                        break;
                    case 3:
                        templateObj.$.ti_widget_image.imagePath = "image/P1_5_ADC.png"
                        break;
                }
            }
            if (jsonObj.signalType !== undefined) {
                console.log("signalType set to " + jsonObj.signalType);
                templateObj.$.ti_widget_droplist_signal_type.selectedIndex = jsonObj.signalType;
                updateDAC();
                // templateObj.$.ti_widget_droplist_signal_type.onchange();
            }
            if (jsonObj.signalFreq !== undefined) {
                console.log("signalFreq set to " + jsonObj.signalFreq);
                templateObj.$.ti_widget_slider_signal_freq.value = Math.log2(jsonObj.signalFreq);
            }
            if (jsonObj.signalAmp !== undefined) {
                console.log("signalAmp set to " + jsonObj.signalAmp);
                templateObj.$.ti_widget_slider_signal_amp.value = Math.round((jsonObj.signalAmp/4095 * 3.3) * 10) / 10;
            }
            if (jsonObj.dacFreq !== undefined) {
                console.log("dacFreq set to " + jsonObj.dacFreq);
                templateObj.$.ti_widget_slider_dac_freq.value = Math.log2(jsonObj.dacFreq);
            }
            if (jsonObj.opAmpMode !== undefined) {
                console.log("opAmpMode set to " + jsonObj.opAmpMode);
                templateObj.$.ti_widget_droplist_opamp_mode.selectedIndex = jsonObj.opAmpMode;
                updateDAC();
                // templateObj.$.ti_widget_droplist_opamp_mode.onchange();
                if (jsonObj.opAmpMode === 0) {
                    templateObj.$.ti_widget_slider_opamp_gain.labels = "1,2,4,8,16,25,32";
                    templateObj.$.ti_widget_slider_opamp_gain.minValue = 1;
                    templateObj.$.ti_widget_slider_opamp_gain.maxValue = 7;
                    
                    var changeCallback = templateObj.$.ti_widget_slider_opamp_gain.onchange;
                    templateObj.$.ti_widget_slider_opamp_gain.onchange = null;
                    templateObj.$.ti_widget_slider_opamp_gain.value = 1;
                    templateObj.$.ti_widget_slider_opamp_gain.onchange = changeCallback;
                    
                    if (templateObj.$.ti_widget_droplist_input_signal_source.selectedIndex === 0)
                        templateObj.$.ti_widget_image.imagePath = "Images/Internal_DAC_Inverting.png"
                }
                else if (jsonObj.opAmpMode == 1) {
                    templateObj.$.ti_widget_slider_opamp_gain.labels = "1,2,3,5,9,17,26,33";
                    templateObj.$.ti_widget_slider_opamp_gain.minValue = 0;
                    templateObj.$.ti_widget_slider_opamp_gain.maxValue = 7;
                    
                    var changeCallback = templateObj.$.ti_widget_slider_opamp_gain.onchange;
                    templateObj.$.ti_widget_slider_opamp_gain.onchange = null;
                    templateObj.$.ti_widget_slider_opamp_gain.value = 0;
                    templateObj.$.ti_widget_slider_opamp_gain.onchange = changeCallback;
                    
                    if (templateObj.$.ti_widget_droplist_input_signal_source.selectedIndex === 0)
                        templateObj.$.ti_widget_image.imagePath = "image/Internal_DAC_Noninverting.png"
                }
            }
            if (jsonObj.opAmpGain !== undefined) {
                console.log("opAmpGain set to " + jsonObj.opAmpGain);
                templateObj.$.ti_widget_slider_opamp_gain.value = jsonObj.opAmpGain;
            }
            if (jsonObj.adcFreq !== undefined) {
                console.log("adcFreq set to " + jsonObj.adcFreq);
                templateObj.$.ti_widget_slider_adc_freq.value = Math.log2(jsonObj.adcFreq);
                adcFreq = jsonObj.adcFreq;
            }
        }
        catch(ex){
            console.log("CustomCodec.decode (from target): strMessage="+strMessage+", exception="+ex);
        }
    }


    // Return true to set the 'Hardware Connected' status in the status bar
    return this.isConnected;

};

CustomCodec.prototype.close = function(){
    gc.databind.unregisterCustomCodec("custom",CustomCodec);
    CustomCodec.initComplete = false;
    CustomCodec.isConnected = false;
};

// Wait for DOMContentLoaded event before trying to access the application template
var init = function() {
    // You can 'chain' codecs together to make it easier to work with the data
    // coming from the device or going to the device.
    // The following codecs are provided:
    //   CR  - use this if the target data uses /n as a delimiter for framing.
    //         The CR codec will take care of buffering the incoming data so that
    //         your codec will only receive complete 'ready to use' packets
    //  If your target uses /n delimited strings, set baseCodecs = "CR"
    //  If your target uses some other format for data (e.g. binary data or custom strings) leave baseCodecs = "undefined"

    var baseCodecs;
    var gcDatabindInitComplete = false;
    var templateInitComplete = false;
    console.log("custom codec: about to register..."); // log a message that you will be able to see in the debugger
    if ((gc) && (gc.databind)) {
        gc.databind.registerCustomCodec("custom",CustomCodec, baseCodecs);
    } else {
        document.addEventListener('gc-databind-ready',function(){
            gc.databind.registerCustomCodec("custom",CustomCodec, baseCodecs);
            gcDatabindInitComplete = true;
            if (templateInitComplete){
                CustomCodec.initComplete = true;
            }
        });
    }

    CustomCodec.templateObj = document.querySelector('#template_obj');
    if (CustomCodec.templateObj) {
        // Wait for the template to fire a dom-change event to indicate that it has been 'stamped'
        // before trying to access components in the application.
        CustomCodec.templateObj.addEventListener('dom-change',function(){
            if (CustomCodec.initComplete) return;
            CustomCodec.templateObj.async(function(){
                templateInitComplete = true;
                if (gcDatabindInitComplete){
                    CustomCodec.initComplete = true;
                }
                console.log("Application template has been stamped.");
                // Now that the template has been stamped, you can use 'automatic node finding' $ syntax to access widgets.
                // e.g. to access a widget with an id of 'widget_id' you can use CustomCodec.templateObj.$.widgetId

            },1);
        });
    } else {
       templateInitComplete = true;
       if (gcDatabindInitComplete){
          CustomCodec.initComplete = true;
       }
       console.log("CustomCodec: Failed to find id template_obj in the Application!");
    }

};

if (document.querySelector('#template_obj')) {
    init();
} else {
    document.addEventListener('DOMContentLoaded',init.bind(this))
}
