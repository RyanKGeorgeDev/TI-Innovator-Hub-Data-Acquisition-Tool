/*
 * gc global variable provides access to GUI Composer infrastructure components and project information.
 * For more information, please see the Working with Javascript guide in the online help.
 */
 
/******************************************************************************* 
 * This function is to handle the Dark mode with night mode toggle switch 
******************************************************************************/
function darkMode() {
    var x = document.getElementById("background");
    var y = document.getElementById("outputbox");
    var z = document.getElementById("boxWithOptions");
    if(document.getElementById("toggleSwitch").checked) {
        x.style.backgroundColor = "black"; 
        y.style.backgroundColor = "#6c6565"; 
        z.style.backgroundColor = "#6c6565"; 
    } else {
        x.style.backgroundColor = "white";
        y.style.backgroundColor = '#C5C5C5';
        z.style.backgroundColor = '#C5C5C5';
        
    }
}

/******************************************************************************
* These functions will handle the color of button when the user selects the 
* options
******************************************************************************/ 

// Function for displaying the oscilioscope
function myFunction1(btn) {
  var x = document.getElementById("osc");

  // lock the buttons
  document.getElementById("fgButton").disabled = true;
  document.getElementById("DLAButton").disabled = true;
  document.getElementById("voltButton").disabled = true;
  document.getElementById("PSButton").disabled = true;

  if(x.style.display === "block") 
  {
    x.style.display = "none";
    btn.style.backgroundColor = "rgb(108,101,101)";
    
    // Unlock the button
    document.getElementById("fgButton").disabled = false;
    document.getElementById("DLAButton").disabled = false;
    document.getElementById("voltButton").disabled = false;
    document.getElementById("PSButton").disabled = false;
  }
  else 
  {
    x.style.display = "block";
    document.getElementById("osc").classList.remove("hidden");
    btn.style.backgroundColor = "green";
  }
}

// Function for displaying the Function Generator
function myFunction2(btn) {
  var x = document.getElementById("fg");

  // If fg is selected lock other buttons
  document.getElementById("oscButton").disabled = true;
  document.getElementById("DLAButton").disabled = true;
  document.getElementById("voltButton").disabled = true;
  document.getElementById("PSButton").disabled = true;
  
  if (x.style.display === "block") {
    x.style.display = "none";
    btn.style.backgroundColor = "rgb(108,101,101)";
    
    // Unlock the buttons
    document.getElementById("oscButton").disabled = false;
    document.getElementById("DLAButton").disabled = false;
    document.getElementById("voltButton").disabled = false;
    document.getElementById("PSButton").disabled = false;
    
  } else {
    x.style.display = "block";
    document.getElementById("fg").classList.remove("hidden");
    btn.style.backgroundColor = "green";
  }
}

// Function for displaying the Digital Logic Analyzer
function myFunction3(btn) {
  var x = document.getElementById("dlaCh");
  
  // Lock the buttons other than DLA
  document.getElementById("oscButton").disabled = true;
  document.getElementById("fgButton").disabled = true;
  document.getElementById("voltButton").disabled = true;
  document.getElementById("PSButton").disabled = true;
  
  if (x.style.display === "block") {
    x.style.display = "none";
    btn.style.backgroundColor = "rgb(108,101,101)";
    
    // unlock the buttons
    document.getElementById("oscButton").disabled = false;
    document.getElementById("fgButton").disabled = false;
    document.getElementById("voltButton").disabled = false;
    document.getElementById("PSButton").disabled = false;
    
  } else {
    x.style.display = "block";
    btn.style.backgroundColor = "green";
    document.getElementById("dlaCh").classList.remove("hidden");
  }
}

// Function for displaying the Voltmeter
function myFunction4(btn) {
  var x = document.getElementById("voltMeter");
  
  // Lock the buttons
  document.getElementById("oscButton").disabled = true;
  document.getElementById("fgButton").disabled = true;
  document.getElementById("DLAButton").disabled = true;
  document.getElementById("PSButton").disabled = true;
  
  if (x.style.display === "block") {
    x.style.display = "none";
    btn.style.backgroundColor = "rgb(108,101,101)";
    
    // unlock the buttons
    document.getElementById("oscButton").disabled = false;
    document.getElementById("fgButton").disabled = false;
    document.getElementById("DLAButton").disabled = false;
    document.getElementById("PSButton").disabled = false;
    
  } else {
    x.style.display = "block";
    btn.style.backgroundColor = "green";
    document.getElementById("voltMeter").classList.remove("hidden");

  }
}

// Function for displaying the Power Supplies
function myFunction5(btn) {
  var x = document.getElementById("powerSupply");
  
  // Lock the buttons not selected
  document.getElementById("oscButton").disabled = true;
  document.getElementById("fgButton").disabled = true;
  document.getElementById("DLAButton").disabled = true;
  document.getElementById("voltButton").disabled = true;
  
  if (x.style.display === "block") {
    x.style.display = "none";
    btn.style.backgroundColor = "rgb(108,101,101)";
  
    // unlock the buttons
    document.getElementById("oscButton").disabled = false;
    document.getElementById("fgButton").disabled = false;
    document.getElementById("DLAButton").disabled = false;
    document.getElementById("voltButton").disabled = false;
      
  } else {
    x.style.display = "block";
    btn.style.backgroundColor = "green";
    document.getElementById("powerSupply").classList.remove("hidden");

  }
}



var gc = gc || {};
gc.services = gc.services || {};


